from metacall import metacall_load_from_file, metacall

def add(a, b):
    return a + b

def multiply_via_js(a, b):
    # Lazy load here!
    metacall_load_from_file('node', ['utils/math_utils.js'])
    return metacall('multiply', a, b)

def complex_calc(a, b):
    # Lazy load here!
    metacall_load_from_file('node', ['utils/math_utils.js'])
    added = add(a, b)
    return metacall('multiply', added, b)